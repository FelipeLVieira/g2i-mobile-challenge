# G2i Trivia Mobile Challenge

This is application was designed focusing modularity, maintainability, industry best practices.
It's made with Typescript and few Javascript files, created with Hooks and Classes, has componentization, uses stack navigation and Context API for state management.

### Installation and Run

```sh
$ yarn install or just $ yarn
$ expo start
```
